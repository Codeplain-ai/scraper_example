import sys
import asyncio
from playwright.async_api import async_playwright, Error as PlaywrightError
from utils import BASE_URL, USER_AGENT, SELECTORS, parse_company_row

async def run_scraper(search_query: str):
    """
    Scraper for Handelsregister (German Company Register).
    Implements search functionality based on 'Company or Keywords'.
    """
    async with async_playwright() as p:
        # Launching browser - mimic real user behavior
        browser = await p.chromium.launch(headless=True) 
        context = await browser.new_context(user_agent=USER_AGENT)
        page = await context.new_page()

        try:
            # 1. Navigate to the Website
            print(f"Navigating to: {BASE_URL}")
            await page.goto(BASE_URL, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(1000)

            # 2. Locate the search input field
            try:
                # Handle possible cookie dialog
                for selector in SELECTORS["cookie_buttons"]:
                    try:
                        button = page.locator(selector).first
                        if await button.is_visible(timeout=2000):
                            await button.click()
                            print(f"Closed cookie/overlay using: {selector}")
                    except:
                        continue

                # Multi-layered locator strategy
                search_field = page.get_by_label(SELECTORS["search_input_label_en"])
                if await search_field.count() == 0:
                    search_field = page.locator(SELECTORS["search_input_id"])
                if await search_field.count() == 0:
                    search_field = page.get_by_label(SELECTORS["search_input_label_de"])

                await search_field.first.wait_for(state="visible", timeout=20000)
                search_field = search_field.first
            except Exception as e:
                raise RuntimeError(f"Failed to locate search field. URL: {page.url}. Error: {str(e)}")

            # 3. Enter query and settings
            print(f"Entering search query: {search_query}")
            await search_field.fill(search_query)
            
            try:
                exact_match_label = page.locator(SELECTORS["exact_match_radio"]).first
                if await exact_match_label.is_visible(timeout=5000):
                    await exact_match_label.click()
            except Exception as e:
                print(f"Warning: Could not select 'Exact match': {e}")

            try:
                all_firms_label = page.locator(SELECTORS["all_firms_radio"]).first
                if await all_firms_label.is_visible(timeout=3000):
                    await all_firms_label.click()
            except Exception as e:
                print(f"Note: Could not select 'All firms': {e}")

            # 4. Submit
            print("Submitting search...")
            submit_button = page.get_by_role("button", name="Suchen")
            if await submit_button.count() == 0:
                submit_button = page.locator(SELECTORS["submit_button"])
            await submit_button.first.click()

            # 5. Wait for results
            try:
                await page.wait_for_selector(f"{SELECTORS['results_table']}, .ui-messages-info", state="visible", timeout=20000)
                # Print HTML for debugging as per requirements
                print("--- HTML CONTENT AFTER SEARCH ---")
                print(await page.content())
            except:
                print(f"Warning: Results container not found.")

            # 6. Result handling
            rows = page.locator(SELECTORS["results_rows"])
            row_count = await rows.count()
            match_found = False
            found_names = []

            for i in range(row_count):
                row = rows.nth(i)
                parsed_data = parse_company_row(await row.inner_text())
                
                cleaned_name = parsed_data["name"]
                registration_info = parsed_data["registration"]
                
                if not cleaned_name:
                    name_element = row.locator(".paddingBottom20Px, strong").first
                    if await name_element.count() > 0:
                        cleaned_name = (await name_element.inner_text()).strip()

                found_names.append(cleaned_name)

                if cleaned_name and cleaned_name.lower() == search_query.lower():
                    print(f"SUCCESS: Exact match found: '{cleaned_name}'")
                    if registration_info:
                        print(f"Registration: {registration_info}")
                    
                    try:
                        download_link = row.get_by_role("link", name="AD")
                        if await download_link.count() == 0:
                            download_link = row.locator(SELECTORS["download_ad_link"])

                        if await download_link.count() > 0:
                            print("Attempting to download 'Aktueller Abdruck'...")
                            async with page.expect_download() as download_info:
                                await download_link.first.click()
                            download = await download_info.value
                            
                            file_path = f"aktueller_abdruck_{search_query.replace(' ', '_')}.pdf"
                            await download.save_as(file_path)
                            print(f"Successfully downloaded PDF to: {file_path}")
                        else:
                            print("Warning: Could not find the 'AD' (Aktueller Abdruck) link in the matching row.")
                    except Exception as download_err:
                        print(f"Error during PDF download: {str(download_err)}")

                    match_found = True
                    break
            
            if not match_found:
                raise RuntimeError(
                    f"No exact match found for '{search_query}'. "
                    f"Names found on page: {found_names}"
                )

            print("Search functionality executed successfully.")

        except PlaywrightError as e:
            print(f"CRITICAL: A Playwright error occurred: {str(e)}", file=sys.stderr)
            sys.exit(1)
        except Exception as e:
            print(f"CRITICAL: An unexpected error occurred: {str(e)}", file=sys.stderr)
            print(f"Traceback information may follow for debugging.", file=sys.stderr)
            sys.exit(1)
        finally:
            await browser.close()

if __name__ == "__main__":
    # Example usage: python scraper.py "Example Company"
    query = sys.argv[1] if len(sys.argv) > 1 else "Volkswagen"
    asyncio.run(run_scraper(query))