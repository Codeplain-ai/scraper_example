import re
from typing import List, Dict, Optional

# Configuration and Selectors
BASE_URL = "https://www.handelsregister.de/rp_web/normalesuche/welcome.xhtml"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"

SELECTORS = {
    "cookie_buttons": [
        "button:has-text('Annehmen')",
        "button:has-text('Akzeptieren')",
        "#piwik_ignore_ok",
        ".ui-button-text:has-text('OK')"
    ],
    "search_input_id": "input#form\\:schlagwoerter",
    "search_input_label_de": "Firma oder Schlagwörter:",
    "search_input_label_en": "Company or Keywords",
    "exact_match_radio": "label[for$='schlagwortOptionen:2']",
    "all_firms_radio": "label[for$='allTechnik:1']",
    "submit_button": "#form\\:sucheAbschicken",
    "results_table": "[id$='SuchErgebnisFormTable']",
    "results_rows": "[id$='SuchErgebnisFormTable'] .ui-datatable-data > tr",
    "download_ad_link": "a:has-text('Aktueller Abdruck')"
}

def parse_company_row(raw_text: str) -> Dict[str, str]:
    """
    Parses a raw text string from a result row into a structured dictionary.
    """
    lines = [line.strip() for line in raw_text.splitlines() if line.strip()]
    data = {"name": "", "registration": ""}
    
    # Try to find the company name prefixed by 'Firma:'
    for line in lines:
        if line.startswith("Firma:"):
            data["name"] = line.replace("Firma:", "").strip()
        
        # Look for registration markers
        if any(reg in line for reg in ["HRB", "HRA", "GnR", "PR", "VR"]) or (line.isdigit() and len(line) > 2):
            data["registration"] = (data["registration"] + " " + line).strip()
            
    return data