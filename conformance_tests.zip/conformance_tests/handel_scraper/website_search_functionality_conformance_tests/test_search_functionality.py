import unittest
import subprocess
import sys
import os

class TestHandelsregisterSearch(unittest.TestCase):
    """
    Conformance tests for the Handelsregister scraper search functionality.
    This test executes the implementation as a subprocess to verify the 
    functionality against the live website as required.
    """

    @classmethod
    def setUpClass(cls):
        """Ensure dependencies and browser binaries are installed."""
        print("[INFO] Preparing environment for Playwright...")
        try:
            # Install requirements
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
            # Install playwright browsers
            subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
        except Exception as e:
            print(f"[ERROR] Failed to setup environment: {e}")

    def setUp(self):
        self.search_query = "bsa project gmbh"
        # Path to the implementation script
        # The build folder is the current directory in the test execution context
        self.scraper_path = os.path.join(os.getcwd(), "scraper.py")
        
        if not os.path.exists(self.scraper_path):
            self.fail(f"Implementation file not found at {self.scraper_path}")

    def test_search_execution_flow(self):
        """
        Verify that the scraper can locate the 'Company or Keywords' field,
        input the query, and submit the search successfully.
        """
        print(f"\n[INFO] Starting conformance test with query: '{self.search_query}'")
        
        # Execute the implementation code as a separate process
        # Use sys.executable to ensure we use the same environment
        try:
            process = subprocess.Popen(
                [sys.executable, self.scraper_path, self.search_query],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            stdout, stderr = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            self.fail("The scraper execution timed out (exceeded 60 seconds).")
        except Exception as e:
            self.fail(f"Failed to execute scraper: {str(e)}")

        # Log the output for debugging as per :plainTestReqs:
        print("--- SCRAPER STDOUT ---")
        print(stdout)
        print("--- SCRAPER STDERR ---")
        print(stderr)

        # Assertions based on expected output logs from scraper.py
        self.assertEqual(process.returncode, 0, f"Scraper exited with error code {process.returncode}. Stderr: {stderr}")
        
        # Check for navigation log
        self.assertIn("Navigating to:", stdout, "Scraper did not log navigation start.")
        
        # Check if the search query was entered
        self.assertIn(f"Entering search query: {self.search_query}", stdout, 
                     "Scraper log does not confirm the correct search query was entered.")
        
        # Check for submission log
        self.assertIn("Submitting search...", stdout, "Scraper log does not confirm search submission.")
        
        # Check for final success message
        self.assertIn("Search functionality executed successfully.", stdout, 
                     "The final success confirmation log is missing from the output.")

        # Verify that HTML content was retrieved (Checking that we aren't getting empty responses)
        self.assertIn("--- HTML CONTENT AFTER SEARCH ---", stdout, "No HTML content found after search.")
        
        print("[INFO] Conformance test passed successfully.")

if __name__ == "__main__":
    unittest.main()