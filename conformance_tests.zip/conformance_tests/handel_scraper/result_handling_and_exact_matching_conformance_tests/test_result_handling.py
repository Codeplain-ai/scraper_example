import subprocess
import unittest
import sys

class TestResultHandling(unittest.TestCase):
    """
    Conformance tests for result handling functionality in the scraper.
    Focuses on exact, case-insensitive matching and exclusion of partial matches.
    """

    def run_scraper_process(self, query):
        """Helper to run the scraper as an external process and capture output."""
        print(f"\n[DEBUG] Executing scraper with query: '{query}'")
        try:
            # We run the actual scraper script as a subprocess to test the system as a whole
            result = subprocess.run(
                [sys.executable, "scraper.py", query],
                capture_output=True,
                text=True,
                timeout=120 # Live websites can be slow
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            self.fail(f"Scraper timed out for query: {query}")

    def test_exact_case_insensitive_matching(self):
        """
        Test 1: test_exact_case_insensitive_matching
        Verify that 'bsa project gmbh' matches 'BSA Project GmbH' (case-insensitive).
        """
        query = "bsa project gmbh"
        return_code, stdout, stderr = self.run_scraper_process(query)

        print(f"[LOGS] STDOUT:\n{stdout}")
        if stderr:
            print(f"[LOGS] STDERR:\n{stderr}")

        # Requirement: Identify correct result by matching exact search query (case insensitive)
        # Success message in scraper.py: "SUCCESS: Exact match found"
        self.assertEqual(return_code, 0, f"Scraper failed to execute successfully for query '{query}'")
        self.assertIn("SUCCESS: Exact match found", stdout, 
                     f"Scraper did not log a success for exact case-insensitive match: '{query}'")
        self.assertIn("Search functionality executed successfully", stdout)

    def test_exclusion_of_partial_matches(self):
        """
        Test 2: test_exclusion_of_partial_matches
        Verify that a query like 'bsa project' does NOT match 'BSA Project GmbH'.
        Partial matches must be excluded.
        """
        # Using a substring that definitely exists as part of the known entity but isn't the whole name
        query = "bsa project"
        return_code, stdout, stderr = self.run_scraper_process(query)

        print(f"[LOGS] STDOUT:\n{stdout}")
        if stderr:
            print(f"[LOGS] STDERR:\n{stderr}")

        # Requirement: Partial matches are not allowed.
        # If 'bsa project gmbh' is found, the scraper should reject it as a match for 'bsa project'
        # and eventually exit with code 1 and "No exact match found" if no other results match perfectly.
        
        # We expect a failure (RuntimeError in script results in exit code 1)
        self.assertEqual(return_code, 1, "Scraper should have failed for a partial match query.")
        self.assertIn("No exact match found", stderr + stdout, 
                     f"Scraper incorrectly accepted or failed to report missing exact match for partial query: '{query}'")
        
        # Verify it didn't log the success message
        self.assertNotIn("SUCCESS: Exact match found", stdout, 
                        "Scraper incorrectly flagged a partial match as an exact match.")

    def test_specific_company_match_with_code(self):
        """
        Test 3: test_specific_company_match_with_code
        Verify that 'bork gmbh' matches 'Bork GmbH' and includes code '9165'.
        """
        query = "bork gmbh"
        return_code, stdout, stderr = self.run_scraper_process(query)

        print(f"[LOGS] STDOUT:\n{stdout}")
        if stderr:
            print(f"[LOGS] STDERR:\n{stderr}")

        self.assertEqual(return_code, 0, f"Scraper failed for query '{query}'")
        self.assertIn("SUCCESS: Exact match found", stdout)
        self.assertIn("Bork GmbH", stdout, "Company name 'Bork GmbH' not found in output.")
        self.assertIn("9165", stdout, f"The expected code '9165' was not found in the scraper output for '{query}'.")

if __name__ == "__main__":
    unittest.main()