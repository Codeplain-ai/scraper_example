import os
import subprocess
import unittest
import logging

# Configure logging to provide extensive debug information as per :plainTestReqs:
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestHandelScraperDownload(unittest.TestCase):
    """
    Conformance tests for the download functionality of the handel_scraper module.
    Validates that 'Aktueller Abdruck' PDF is saved correctly for 'bsa project gmbh'.
    """

    def setUp(self):
        self.search_query = "bsa project gmbh"
        # The expected filename based on scraper.py logic: 
        # file_path = f"aktueller_abdruck_{search_query.replace(' ', '_')}.pdf"
        self.expected_filename = "aktueller_abdruck_bsa_project_gmbh.pdf"
        
        # Cleanup before test
        if os.path.exists(self.expected_filename):
            os.remove(self.expected_filename)
            logger.info(f"Removed existing file: {self.expected_filename}")

    def tearDown(self):
        # Optional: cleanup after test if desired, but kept for verification
        pass

    def test_aktueller_abdruck_pdf_download_and_storage(self):
        """
        Execute the scraper and verify the PDF for 'bsa project gmbh' is downloaded.
        Maps to :codeplain::Plan: Test 1.
        """
        logger.info(f"Starting conformance test for query: {self.search_query}")
        
        # Execute the implementation code as a subprocess to test functionality indirectly
        # We assume the environment has playwright and dependencies installed as per requirements.txt
        try:
            process = subprocess.run(
                ["python3", "scraper.py", self.search_query],
                capture_output=True,
                text=True,
                timeout=120  # Sufficient time for web automation
            )
            
            # Log the output for debugging as per :plainTestReqs:
            logger.info("--- Scraper STDOUT ---")
            logger.info(process.stdout)
            
            if process.stderr:
                logger.error("--- Scraper STDERR ---")
                logger.error(process.stderr)

            # Check if the process finished successfully
            self.assertEqual(process.returncode, 0, f"Scraper failed with return code {process.returncode}")

            # Verify the file existence in the current directory
            file_exists = os.path.exists(self.expected_filename)
            
            self.assertTrue(
                file_exists, 
                f"Expected PDF file '{self.expected_filename}' was not found in the current directory."
            )

            # Verify file properties (should not be empty)
            if file_exists:
                file_size = os.path.getsize(self.expected_filename)
                logger.info(f"Successfully verified '{self.expected_filename}'. Size: {file_size} bytes.")
                self.assertGreater(file_size, 0, "Downloaded PDF file is empty.")
            
            # Verify logs confirm successful download completion
            self.assertIn("Successfully downloaded PDF", process.stdout, "Logs do not indicate a successful download.")

        except subprocess.TimeoutExpired:
            self.fail("The scraper execution timed out.")
        except Exception as e:
            self.fail(f"An error occurred during the test execution: {str(e)}")

if __name__ == "__main__":
    unittest.main()