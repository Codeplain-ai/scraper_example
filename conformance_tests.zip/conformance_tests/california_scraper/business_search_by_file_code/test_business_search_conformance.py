import unittest
import logging
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

# Configure logging for test visibility
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TestCaliforniaBusinessSearch(unittest.TestCase):
    """
    Conformance tests for the California Business Search scraper.
    Optimized to run within global timeout limits by performing search once.
    """
    
    BASE_URL = "https://bizfileonline.sos.ca.gov/search/business"
    FILE_CODE = "3993376"
    TIMEOUT = 15000  # 15 seconds
    REDIRECT_TIMEOUT = 30000 # 30 seconds for OAuth redirects

    @classmethod
    def setUpClass(cls):
        """Perform the search once for all tests in this class to save time."""
        cls.playwright = sync_playwright().start()
        cls.browser = cls.playwright.chromium.launch(headless=True)
        cls.context = cls.browser.new_context(
            viewport={'width': 1280, 'height': 800},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        )
        cls.page = cls.context.new_page()
        
        try:
            logger.info(f"Navigating to {cls.BASE_URL}")
            # Use 'load' to ensure scripts are ready for interaction
            cls.page.goto(cls.BASE_URL, wait_until="load")
            
            # Locate and fill search input
            search_input = cls.page.get_by_placeholder("Search by name or file number")
            search_input.wait_for(state="visible", timeout=cls.TIMEOUT)
            
            logger.info(f"Searching for FileCode: {cls.FILE_CODE}")
            search_input.click() # Ensure focus
            search_input.fill(cls.FILE_CODE)
            
            # Trigger search
            search_input.press("Enter")
            
            # Wait for result and click it
            logger.info("Waiting for search results to appear...")
            
            # Use a broader locator for the result. Sometimes it's a link, sometimes text in a div.
            result_locator = cls.page.locator(f"div[role='grid'] >> text='{cls.FILE_CODE}'").first
            
            try:
                result_locator.wait_for(state="visible", timeout=cls.TIMEOUT)
            except PlaywrightTimeoutError:
                logger.warning("Result not visible after Enter. Attempting explicit button click...")
                # Try to find the search button by common classes/icons in SOS portals
                search_button = cls.page.locator("button:has(i.fa-search), button.search-button, .search-input-group button").first
                if search_button.is_visible():
                    search_button.click(force=True)
                result_locator.wait_for(state="visible", timeout=cls.TIMEOUT)

            logger.info("Clicking result and waiting for detail panel...")
            
            # Navigate to the link associated with the file code
            result_link = cls.page.locator(f"a:has-text('{cls.FILE_CODE}')").first
            result_link.click()
            
            # Handle potential OAuth2 redirects by waiting for the final URL and network stability
            cls.page.wait_for_url("**/search/business/details/**", timeout=cls.REDIRECT_TIMEOUT)
            cls.page.wait_for_load_state("networkidle")
            
            # Look for 'Entity Details' which signals we are on the right page
            cls.page.wait_for_selector("text=Entity Details", timeout=cls.REDIRECT_TIMEOUT)
            
            # Wait for the specific data fields to be rendered
            cls.page.get_by_text("Initial Filing Date", exact=True).first.wait_for(state="visible", timeout=cls.TIMEOUT)
            
            logger.info("Search results loaded and detail panel opened.")
            
        except Exception as e:
            logger.error(f"Failed to set up test state: {e}")
            cls.tearDownClass()
            raise

    @classmethod
    def tearDownClass(cls):
        if hasattr(cls, 'context'): cls.context.close()
        if hasattr(cls, 'browser'): cls.browser.close()
        if hasattr(cls, 'playwright'): cls.playwright.stop()

    def get_value_by_label(self, label):
        """Helper to find text value in the SOS detail grid."""
        # First attempt: Pure Playwright locator for common SOS grid patterns
        locators = [
            self.page.locator(f"div:has-text('{label}') + div").first,
            self.page.locator(f"dt:has-text('{label}') + dd").first,
            self.page.locator(f"div.label:has-text('{label}') + div.value").first
        ]
        
        for loc in locators:
            try:
                if loc.is_visible(timeout=1000):
                    text = loc.inner_text().strip()
                    if text: return text
            except:
                continue

        # Second attempt: JS traversal for more complex nested structures
        return self.page.evaluate(
            '''(lbl) => {
                const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
                let node;
                while(node = walk.nextNode()) {
                    if (node.textContent.trim() === lbl) {
                        let p = node.parentElement;
                        // Try sibling of parent (common in key-value pairs)
                        if (p.nextElementSibling) return p.nextElementSibling.innerText.trim();
                        // Try sibling of element itself
                        if (node.nextElementSibling) return node.nextElementSibling.innerText.trim();
                    }
                }
                return null;
            }''',
            label
        )

    def test_1_entity_status_and_standing(self):
        """Test 1: Verify Business Entity Status and Standing"""
        logger.info("Checking Status and Standings...")
        self.assertEqual(self.get_value_by_label("Status"), "Active")
        self.assertEqual(self.get_value_by_label("Standing - SOS"), "Good")
        self.assertEqual(self.get_value_by_label("Standing - FTB"), "Good")
        self.assertEqual(self.get_value_by_label("Standing - Agent"), "Good")
        self.assertEqual(self.get_value_by_label("Standing - VCFCF"), "Good")

    def test_2_entity_formation_info(self):
        """Test 2: Verify Entity Formation and Type Information"""
        logger.info("Checking Formation and Entity Type...")
        self.assertEqual(self.get_value_by_label("Formed In"), "CALIFORNIA")
        self.assertEqual(self.get_value_by_label("Entity Type"), "Stock Corporation - CA - General")

    def test_3_address_information(self):
        """Test 3: Verify Registered Address Information"""
        logger.info("Checking Principal and Mailing Addresses...")
        principal = self.get_value_by_label("Principal Address")
        mailing = self.get_value_by_label("Mailing Address")
        
        # Standardizing whitespace for comparison as the site output can vary
        self.assertEqual("1101 ENDEAVOR DR.\nUPLAND, CA 91786", principal)
        # Requirement expects "UPLAND,CA91786" (no space after comma) for mailing
        self.assertEqual("1101 ENDEAVOR DR.\nUPLAND,CA91786", mailing.replace(", ", ","))

    def test_4_filing_and_agent_details(self):
        """Test 4: Verify Filing Deadlines and Agent Details"""
        logger.info("Checking Dates and Agent Details...")
        self.assertEqual(self.get_value_by_label("Initial Filing Date"), "02/13/2017")
        self.assertEqual(self.get_value_by_label("Statement of Info Due Date"), "02/28/2023")
        
        agent_section = self.get_value_by_label("Agent")
        self.assertIn("Individual", agent_section)
        self.assertIn("GRANT WAYNE GRAFIUS", agent_section)
        self.assertIn("1101 ENDEAVOR DR. UPLAND, CA 91786", agent_section.replace('\n', ' '))

if __name__ == "__main__":
    unittest.main()